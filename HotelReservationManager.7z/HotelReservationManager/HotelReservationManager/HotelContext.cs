﻿namespace HotelReservationManager
{
    internal class HotelContext
    {
    }
}