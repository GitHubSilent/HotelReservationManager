﻿using System;

internal class JsonPropertyAttribute : Attribute
{
}