﻿using System;
using System.Runtime.Serialization;

namespace ListHotels
{
    [Serializable]
    internal class OAuthTokenRequestException : Exception
    {
        public OAuthTokenRequestException()
        {
        }

        public OAuthTokenRequestException(string message) : base(message)
        {
        }

        public OAuthTokenRequestException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected OAuthTokenRequestException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}