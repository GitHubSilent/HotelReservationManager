﻿namespace HotelReservationManager
{
    internal class CRUD
    {
        public static object HotelMenu { get; internal set; }
        public static object ReservationMenu { get; internal set; }
        public static object InformationMenu { get; internal set; }
        public static object ManagerMenu { get; internal set; }
    }
}