﻿using System;
using System.Threading;
using static System.Net.Mime.MediaTypeNames;

namespace HotelReservationManager
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            using (HotelContext db = new HotelContext())
            {
                object p = Application.EnableVisualStyles();
                object p1 = Application.SetCompatibleTextRenderingDefault(false);

                SimpleIntroduction();
                while (true)
                {
                    Console.Clear();
                    ListCommands(db);
                    Console.ReadLine();
                }
            }
        }

        static void ListCommands(HotelContext db)
        {
            Console.WriteLine("1 - Our Hotel");
            Console.WriteLine("2 - Information");
            Console.WriteLine("Exit - Exit the program");
            Console.WriteLine();

            Console.Write("Enter your command: ");
            string input = Console.ReadLine();
            Console.WriteLine();

            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Invalid entry!");
            }

            if (input == "exit" || input == "Exit" || input == "0")
            {
                Environment.Exit(0);
            }
            else if (input == "1")
            {
                ListCRUDCommands(db);
            }
            else if (input == "2")
            {
                HotelReservationManager.Filtering.Filters.SelectMenu(db);
            }
        }

        static void ListCRUDCommands(HotelContext db)
        {
            Console.WriteLine("1 - The three names of the guest");
            Console.WriteLine("2 - Date of arrival");
            Console.WriteLine("3 - Date of departure");
            Console.WriteLine("4 - Number of guests");
            Console.WriteLine("5 - Number of rooms");
            Console.WriteLine("6 - Plan the room");
            Console.WriteLine("7 - Contact number or email");
            Console.WriteLine("8 - Method of payment");
            Console.WriteLine("0 - Exit");
            Console.WriteLine();

            Console.Write("Enter your command: ");
            int input = int.Parse(Console.ReadLine());

            if (input < 0)
            {
                Console.WriteLine("Invalid entry!");
            }

            if (input == 0)
            {
                Environment.Exit(0);
            }
            else if (input == 1)
            {
                HotelReservationManager.CRUD.HotelMenu.ListHotelCommands(db);
            }
            else if (input == 2)
            {
                HotelReservationManager.CRUD.ReservationMenu.ListREservationCommands(db);
            }
            else if (input == 3)
            {
                HotelReservationManager.CRUD.InformationMenu.ListInformationCommands(db);
            }
            else if (input == 4)
            {
                HotelReservationManager.CRUD.ManagerMenu.ListManagerCommands(db);
            }
        }

        static void SimpleIntroduction()
        {
            for (int i = 0; i <= 100; i++)
            {
                Console.Write($"\rProgress: {i}%");
                Thread.Sleep(5);
            }

            Console.WriteLine("\nLoading successful!");
            Console.WriteLine("Welcome!");
            Thread.Sleep(500);
        }
    }
}
