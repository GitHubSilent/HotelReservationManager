﻿namespace HotelReservationManager
{
    internal class Filtering
    {
        public static object Filters { get; internal set; }
    }
}